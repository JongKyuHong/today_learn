package com.example.androidjongkyu;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.cloud.FirebaseVisionCloudDetectorOptions;
import com.google.firebase.ml.vision.cloud.label.FirebaseVisionCloudLabel;
import com.google.firebase.ml.vision.cloud.label.FirebaseVisionCloudLabelDetector;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.label.FirebaseVisionLabel;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetector;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetectorOptions;

import java.util.List;

//화상분류(이미지)
public class ViewController extends FrameLayout implements View.OnClickListener {
    //UI
    private ImageView imageView;
    private TextView lblText;
    private Button btnSegmentControl0;
    private Button btnSegmentControl1;
    private int segmentControl = 0;


    //====================
//라이프사이클
//====================
    //컨스트럭터
    public ViewController(Activity activity) {
        super(activity);

        //레이아웃
        this.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        LayoutInflater inflater = (LayoutInflater)activity.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.main, null);
        addView(view);

        //UI
        this.imageView = this.findViewById(R.id.image_view);
        this.lblText = this.findViewById(R.id.lbl_text);
        this.btnSegmentControl0 = this.findViewById(R.id.btn_segment_control0);
        this.btnSegmentControl0.setOnClickListener(this);
        this.btnSegmentControl1 = this.findViewById(R.id.btn_segment_control1);
        this.btnSegmentControl1.setOnClickListener(this);

        //제스처 추가
        view.setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    showActionSheet();
                }
                return false;
            }
        });

        //액션시트 표시
        showActionSheet();
    }


    //====================
//이벤트
//====================
    @Override
    public void onClick(View view) {
        if (view == this.btnSegmentControl0) {
            segmentControl = 0;
            this.btnSegmentControl0.setTextColor(Color.WHITE);
            this.btnSegmentControl0.setBackgroundColor(Color.BLUE);
            this.btnSegmentControl0.setEnabled(false);
            this.btnSegmentControl1.setTextColor(Color.BLUE);
            this.btnSegmentControl1.setBackgroundColor(Color.LTGRAY);
            this.btnSegmentControl1.setEnabled(true);
        } else if (view == this.btnSegmentControl1) {
            segmentControl = 1;
            this.btnSegmentControl0.setTextColor(Color.BLUE);
            this.btnSegmentControl0.setBackgroundColor(Color.LTGRAY);
            this.btnSegmentControl0.setEnabled(true);
            this.btnSegmentControl1.setTextColor(Color.WHITE);
            this.btnSegmentControl1.setBackgroundColor(Color.BLUE);
            this.btnSegmentControl1.setEnabled(false);
        }
    }


    //====================
//액션시트
//====================
    //액션시트 표시
    private void showActionSheet() {
        String[] items = {"카메라", "사진 라이브러리"};
        new AlertDialog.Builder(this.getContext())
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((AppDelegate)getContext()).openPicker(which, new AppDelegate.ICompletion(){
                            public void onCompletion(Bitmap image) {
                                if (image == null) return;
                                imageView.setImageBitmap(image);

                                //예측
                                if (segmentControl == 0) {
                                    detectLabels(image);
                                } else if (segmentControl == 1) {
                                    detectCloudLabels(image);
                                }
                            }
                        });
                    }
                })
                .setNegativeButton("취소", null)
                .show();
    }


    //====================
//경고
//====================
    //경고표시
    private void showAlert(String text) {
        new AlertDialog.Builder(this.getContext())
                .setMessage(text)
                .setPositiveButton("OK", null)
                .show();
    }


    //====================
//화상분류(이미지)
//====================
    //온디바이스API 화상분류(이미지)
    private void detectLabels(Bitmap image) {
        //(1)FirebaseVisionImageの生成
        FirebaseVisionImage visionImage = FirebaseVisionImage.fromBitmap(image);

        //(2)화상분류 옵션 생성
        FirebaseVisionLabelDetectorOptions options =
                new FirebaseVisionLabelDetectorOptions.Builder()
                        .setConfidenceThreshold(0.75f)
                        .build();

        //(3)화상분류 검출기 생성
        FirebaseVisionLabelDetector labelDetector = FirebaseVision.getInstance()
                .getVisionLabelDetector(options);

        //(4)화상분류 실행
        labelDetector.detectInImage(visionImage)
                .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionLabel>>() {
                    //성공시 호출
                    @Override
                    public void onSuccess(List<FirebaseVisionLabel> labels) {
                        //검증결과 획득
                        String text = "\n";
                        for (FirebaseVisionLabel label: labels) {
                            text += label.getLabel()+" : "+
                                    (int)(label.getConfidence()*100)+"%\n";
                        }
                        final String str = text;

                        //UI 업데이트
                        post(new Runnable() {
                            @Override
                            public void run() {
                                lblText.setText(str);
                                lblText.setVisibility(
                                        str.length() == 0 ? View.GONE : View.VISIBLE);
                            }
                        });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    //에러시 호출
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        showAlert(e.getMessage());
                    }
                });
    }

    //클라우드API 화상분류(이미지)j
    private void detectCloudLabels(Bitmap image) {
        //FirebaseVisionImage 생성
        FirebaseVisionImage visionImage = FirebaseVisionImage.fromBitmap(image);

        //(5)화상분류 옵션 생성
        FirebaseVisionCloudDetectorOptions options =
                new FirebaseVisionCloudDetectorOptions.Builder()
                        .setModelType(FirebaseVisionCloudDetectorOptions.LATEST_MODEL)
                        .setMaxResults(20)
                        .build();

        //(6)화상분류 검출기 생성
        FirebaseVisionCloudLabelDetector labelDetector = FirebaseVision.getInstance()
                .getVisionCloudLabelDetector(options);

        //(7)화상분류 실행
        labelDetector.detectInImage(visionImage)
                .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionCloudLabel>>() {
                    //성공시 호출
                    @Override
                    public void onSuccess(List<FirebaseVisionCloudLabel> labels) {
                        //검증결과 획득
                        String text = "\n";
                        for (FirebaseVisionCloudLabel label: labels) {
                            text += label.getLabel()+" : "+
                                    (int)(label.getConfidence()*100)+"%\n";
                        }
                        final String str = text;

                        //UI 업데이트
                        post(new Runnable() {
                            @Override
                            public void run() {
                                lblText.setText(str);
                                lblText.setVisibility(
                                        str.length() == 0 ? View.GONE : View.VISIBLE);
                            }
                        });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    //에러시 호출
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        showAlert(e.getMessage());
                    }
                });
    }
}
