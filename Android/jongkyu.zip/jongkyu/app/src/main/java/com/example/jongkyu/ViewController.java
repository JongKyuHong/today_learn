package com.example.jongkyu;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Camera;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
//import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.ExifInterface;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.annotation.Size;
import androidx.core.app.ActivityCompat;
import androidx.core.content.PermissionChecker;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.cloud.FirebaseVisionCloudDetectorOptions;
import com.google.firebase.ml.vision.cloud.label.FirebaseVisionCloudLabel;
import com.google.firebase.ml.vision.cloud.label.FirebaseVisionCloudLabelDetector;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.common.FirebaseVisionImageMetadata;
import com.google.firebase.ml.vision.label.FirebaseVisionLabel;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetector;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetectorOptions;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

public class ViewController {
    private final static int REQUEST_PERMISSIONS = 0;
    private final static String[] PERMISSIONS = {
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.READ_EXTERNAL_STORAGE
    };
    private final static int REQUEST_PICKER = 0;
    private Uri cameraUri;
    private ICompletion openPickerCompletion;
    public interface ICompletion{
        void onCompletion(Bitmap image);
    }
    private boolean permissionGranted = false;
    FirebaseVisionImage visionImage = FirebaseVisionImage.fromBitmap(image);

    public void openPicker(int sourceType, ICompletion completion){
        openPickerCompletion = completion;
        if(!permissionGranted) return;

        if(sourceType == 0){
            String photoName = DateFormat.format("yyyyMMddkkmmss",
                    System.currentTimeMillis()).toString() + ".jpg";
            ContentValues contentValues = new ContentValues();
            contentValues.put(MediaStore.Images.Media.TITLE, photoName);
            contentValues.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            this.cameraUri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
            Intent intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intentCamera.putExtra(MediaStore.EXTRA_OUTPUT,this.cameraUri);
            startActivityForResult(intentCamera, REQUEST_PICKER);
        }
    }
    @Override
    public void onActivityResult(int requestCode,int resultCode, Intent resultData)
    {
        if(requestCode == REQUEST_PICKER){
            if(resultCode != Activity.RESULT_OK){
                openPickerCompletion.onCompletion(null);
            }
            Bitmap image = null;
            InputStream in = null;
            if(this.cameraUri != null){
                final List<String> paths = cameraUri.getPathSegments();
                String strId = paths.get(3);
                Cursor crsCursor = getContentResolver().query(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        new String[]{MediaStore.MediaColumns.DATA},
                        "_id=?",
                        new String[]{strId},
                        null
                );
                crsCursor.moveToFirst();
                String filePath = crsCursor.getString(0);
                try{
                    in = new FileInputStream(filePath);
                    image = BitmapFactory.decodeFile(filePath);
                    image = modifyOrientation(image,in);
                    in.close();
                }catch (Exception e){
                    try{
                        if(in != null) in.close();
                    }catch(Exception e2){

                    }
                }
            }else if(resultData != null){
                try{
                    in = getContentResolver().openInputStream(resultData.getData());
                    image = BitmapFactory.decodeStream(in);
                    in.close();
                    in = getContentResolver().openInputStream(resultData.getData());
                    image = modifyOrientation(image, in);
                    in.close();
                }catch(Exception e){
                    try{
                        if(in!=null) in.close();
                    }catch(Exception e2){

                    }
                }
            }
            openPickerCompletion.onCompletion(image);
        }
    }
    private void checkPermission(){
        if(isGranted()){
            permissionGranted = true;
        }else{
            ActivityCompat.requestPermissions(this,PERMISSIONS,REQUEST_PERMISSIONS);
        }
    }
    private boolean isGranted(){
        for(int i =0; i<PERMISSION.length; i++){
            if(PermissionChecker.checkSelfPermission(
                    AppDelegate.this, PERMISSIONS[i]) !=
                    PackageManager.PERMISSION_GRANTED) {
                    return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requsetCode, String permissions[], int[] results){
        if(requestCode == REQUEST_PERMISSIONS){
            permissionGranted = true;
        }else{
            super.onRequestPermissionsResult(requestCode, permissions, results);
        }
    }

    public void initCapture() {
        HandlerThread thread = new HandlerThread("work");
        thread.start();
        this.workHandler = new Handler(thread.getLooper());
        this.manager = (CameraManager)activity.getSystemService(Context.CAMERA_SERVICE);
        this.textureView.setSurfaceTextureListener(
            new TextureView.SurfaceTextureListener(){
            @Override
            public void onSurfaceTextureAvailable(
                    SurfaceTexture surface, int width, int height){
                    startCamera();
            }
            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surface,
                                                    int width, int height) {
            }
            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture surface){
            }
            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture surface){
                stopCamera();
                return true;
            }
        });
        if(this.textureView.isAailable()) startCamera();
    }
    public void startCamera(){
        try{
            this.cameraId = getCameraId();
            this.cameraInfo = manager.getCameraCharacteristics(this.cameraId);
            this.previewSize = getPreviewSize(this.cameraInfo);

            int sw = Math.min(previewSize.getWidth(), previewSize.getHeight());
            int sh = Math.max(preview.getWidth(), preview.getHeight());
            float scale =
                    ((float)getWidth()/(float)sw > (float)getHeight()/(float)sh) ? (float)getWidth()/(float)sw : (float)getHeight()/(float)sh;
            RelativeLayout.LayoutParmas params = new RelativeLayout.LayoutParams(sw,sh);
            params.addRule(RelativeLayout.CENTER_IN_PARENT);
            textureView.setLaoutParams(params);
            textureView.setScaleX(scale);
            textureView.setScaleY(scale);

            this.manager.openCamera(this.cameraId, new CameraDevice.StateCallback(){

                @Override
                public void onOpened(Camera camera){
                    ViewController.this.camera = camera;
                    initPreview();
                    startPreview();
                }
                @Override
                public void onDisconnected(CameraDevice camera){
                    stopCamera();
                }
                @Override
                public void onError(CameraDevice camera, int error){
                    stopCamera();
                }
            }, null);
        }catch(SecurityException e){
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public void stopCamera(){
        if(this.camera == null) return;
        this.camera.close();
        this.camera = null;
    }
    private String getCameraId(){
        try{
            for(String cameraId : manager.getCameraIdList()){
                CameraCharacteristics cameraInfo = manager.getCameraCharacteristics(cameraId);
                if(cameraInfo.get(CameraCharacteristics.LENS_FACING) ==
                CameraCharacteristics.LENS_FACING_BACK){
                    return cameraId;
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    private Size getPreviewSize(CameraCharacteristics characteristics){
        StreamConfigurationMap map = characteristics.get(
                CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        Size[] sizes = map.getOutputSizes(SurfaceTexture.class);
        for (int i = 0; i <sizes.length; i++){
            if(sizes[i].getWidth() < 1000 && sizes[i].getHeight() < 1000){
                return sizes[i];
            }
        }
        return sizes[0];
    }

    private void initPreview(){
        if(this.camera == null) return;
        SurfaceTexture texture = this.textureView.getSurfaceTexture();
        if(texture == null) return;
        texture.setDefaultBufferSize(this.previewSize.getWidth(), this.getPreviewSize.getHeight());
        this.surface = new Surface(texture);

        this.imageReader = ImageReader.newInstance(
                this.previewSize.getWidth(), this.previewSize.getHeight(),
                ImageFormat.JPEG,10);
                this.imageReader.setOnImageAvailableListener(new ImageReader.
                        OnImageAvailableListener(){
                    @Override
                    public void onImageAvailable(ImageReader reader){
                        try{
                            Image image = reader.acquireLatestImage();
                            detectLabels(image);
                            image.close();
                        }catch(Exception e){

                        }
            }
        },workHandler);
        try{
            this.previewBuilder = this.camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            this.previewBuilder.addTarget(surface);
            this.previewBuilder.addTarget(imageReader.getSurface());
            this.previewBuilder.set(CaptureRequest.JPEG_ORIENTATION,getOrientation());
            this.previewBuilder.set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            this.previewBuilder.set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON);

        }catch(CameraAccessException e){
            e.printStackTrace();
        }
    }

    private int getOrientation(){
        try{
            int deviceRotation = activity.getWindowManager().getDefaultDisplay().getRotation();
            int rotation = ORIENTATIONS.get(deviceRotation);

            CameraManager cameraManager = (CameraManager)activity.getSystemService(Activity.CAMERA_SERVICE);
            int sensorOrientation = cameraManager
                    .getCameraCharacteristics(this.cameraId)
                    .get(CameraCharacteristics.SENSOR_ORIENTATION);
            return (rotation + sensorOrientation + 270) % 360;
        }catch(Exception e){
            e.printStackTrace();

            return 0;
        }
    }

    private void startPreview(){
        if(this.camera == null) return;
        try{
            this.camera.createCaptureSession(Arrays.asList(surface,imageReader.getSurface()),
                    new CameraCaptureSession.StateCallback(){
                        @Override
                        public void onConfigured(CameraCaptureSession session){
                            if(ViewController.this.camera == null) return;
                            try{
                                session.setRepeatingRequest(
                                        ViewController.this.previewBuilder.build(),
                                        null,
                                        ViewController.this.workHandler);

                            }catch(CameraAccessException e){
                                e.printStackTrace();
                            }
                        }
                        @Override
                        public void onConfigureFailed(CameraCaptureSession session){

                        }
                    }, this.workHandler);
        }catch(CameraAccessException e){
            e.printStackTrace();
        }
    }

//    FirebaseVisionImage visionImage = FirebaseVisionImage.fromMediaImage(
//            image, FirebaseVisionImageMetadata.ROTATION_0);
//    )



    public static Bitmap modifyOrientation(Bitmap bitmap, InputStream in){
        try{
            ExifInterface ei = new ExifInterface(in);
            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
            if(orientation == ExifInterface.ORIENTATION_ROTATE_90){
                return rotate(bitmap,90);
            }else if(orientation == ExifInterface.ORIENTATION_ROTATE_180){
                return rotate(bitmap,180);
            }else if(orientation == ExifInterface.ORIENTATION_ROTATE_270){
                return rotate(bitmap,270);
            }else if(orientation == ExifInterface.ORIENTATION_FLIP_HORIZONTAL){
                return flip(bitmap,true,false);
            }else if(orientation == ExifInterface.ORIENTATION_FLIP_VERTICAL){
                return flip(bitmap,false,true);
            }
        }catch(IOException e){
            e.printStackTrace();
        }
        return bitmap;
    }

    public static Bitmap rotate(Bitmap bitmap, float degrees){
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bitmap, 0, 0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    }

    public static Bitmap flip(Bitmap bitmap, boolean horizontal, boolean vertical){
        Matrix matrix = new Matrix();
        matrix.preScale(horizontal ? -1 : 1, vertical ? -1 : 1);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    }

//    FirebaseVisionLabelDetectorOptions options =
//            new FirebaseVisionLabelDetectorOptions.Builder()
//            .setConfidenceThreshold(0.75f)
//            .build();
//    FirebaseVisionLabelDetector labelDetector = FirebaseVision.getInstance()
//            .getVisionLabelDetector(options);
//
//    labelDetector.detectInImage(visionImage)
//            .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionLabel>>(){
//
//                @Override
//                public void onSuccess(List<FirebaseVisionLabel> labels){
//                    String text = "\n";
//                    for(FirebaseVisionLabel label: labels){
//                        text += label.getLabel()+" : " + (int)(label.getConfidence()*100)+"%\n";
//                    }
//                    final String str = text;
//
//                    post(new Runnable(){
//                        @Override
//                        public void run() {
//                            lblText.setText(str);
//                            lblText.setVisibility(
//                                    str.length() == 0 ? View.GONE : View.VISIBLE);
//                        }
//                    });
//                }
//            })
//            .addOnFailureListener(new OnFailureListener(){
//                @Override
//                public void OnFailure(@NonNull Exception e){
//                    showAlert(e.getMessage());
//                }
//                });
//            }
    FirebaseVisionCloudDetectorOptions options = new FirebaseVisionCloudDetectorOptions.Builder()
        .setModelType(FirebaseVisionCloudDetectorOptions.LATEST_MODEL)
        .setMaxResults(20)
        .build();
    FirebaseVisionCloudLabelDetector labelDetector = FirebaseVision.getInstance()
            .getVisionCloudLabelDetector(options);

    labelDetector.detectInImage(visionImage)
            .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionCloudLabel>>()
    {
        @Override
        public void onSuccess(List<FirebaseVisionCloudLabel> labels){
            String text = "\n";
            for(FirebaseVisionLabel label: labels){
                text += label.getLabel()+" : " +
                        (int)(label.getConfidence()*100)+"%\n";
            }
            final String str = text;

            post(new Runnable(){
                @Override
                public void run() {
                        lblText.setText(str);
                        lblText.setVisibility(
                                str.length() == 0 ? View.GONE : View.VISIBLE);
                    }
                });
            }
        })
            .addOnFailureListener(new OnFailureListener(){
            @Override
            public void OnFailure(@NonNull Exception e){
                showAlert(e.getMessage());
            }
        });
    }



