package com.example.jongkyu;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.PermissionChecker;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.cloud.FirebaseVisionCloudDetectorOptions;
import com.google.firebase.ml.vision.cloud.label.FirebaseVisionCloudLabel;
import com.google.firebase.ml.vision.cloud.label.FirebaseVisionCloudLabelDetector;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.label.FirebaseVisionLabel;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetector;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetectorOptions;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class ViewController {
    private final static int REQUEST_PERMISSIONS = 0;
    private final static String[] PERMISSIONS = {
        Manifest.permission.WRITE_EXTERNAL_STORAGE,
        Manifest.permission.READ_EXTERNAL_STORAGE
    };
    private final static int REQUEST_PICKER = 0;
    private Uri cameraUri;
    private ICompletion openPickerCompletion;
    public interface ICompletion{
        void onCompletion(Bitmap image);
    }
    private boolean permissionGranted = false;
    FirebaseVisionImage visionImage = FirebaseVisionImage.fromBitmap(image);

    public void openPicker(int sourceType, ICompletion completion){
        openPickerCompletion = completion;
        if(!permissionGranted) return;

        if(sourceType == 0){
            String photoName = DateFormat.format("yyyyMMddkkmmss",
                    System.currentTimeMillis()).toString() + ".jpg";
            ContentValues contentValues = new ContentValues();
            contentValues.put(MediaStore.Images.Media.TITLE, photoName);
            contentValues.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            this.cameraUri = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
            Intent intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intentCamera.putExtra(MediaStore.EXTRA_OUTPUT,this.cameraUri);
            startActivityForResult(intentCamera, REQUEST_PICKER);
        }
    }
    @Override
    public void onActivityResult(int requestCode,int resultCode, Intent resultData)
    {
        if(requestCode == REQUEST_PICKER){
            if(resultCode != Activity.RESULT_OK){
                openPickerCompletion.onCompletion(null);
            }
            Bitmap image = null;
            InputStream in = null;
            if(this.cameraUri != null){
                final List<String> paths = cameraUri.getPathSegments();
                String strId = paths.get(3);
                Cursor crsCursor = getContentResolver().query(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        new String[]{MediaStore.MediaColumns.DATA},
                        "_id=?",
                        new String[]{strId},
                        null
                );
                crsCursor.moveToFirst();
                String filePath = crsCursor.getString(0);
                try{
                    in = new FileInputStream(filePath);
                    image = BitmapFactory.decodeFile(filePath);
                    image = modifyOrientation(image,in);
                    in.close();
                }catch (Exception e){
                    try{
                        if(in != null) in.close();
                    }catch(Exception e2){

                    }
                }
            }else if(resultData != null){
                try{
                    in = getContentResolver().openInputStream(resultData.getData());
                    image = BitmapFactory.decodeStream(in);
                    in.close();
                    in = getContentResolver().openInputStream(resultData.getData());
                    image = modifyOrientation(image, in);
                    in.close();
                }catch(Exception e){
                    try{
                        if(in!=null) in.close();
                    }catch(Exception e2){

                    }
                }
            }
            openPickerCompletion.onCompletion(image);
        }
    }
    private void checkPermission(){
        if(isGranted()){
            permissionGranted = true;
        }else{
            ActivityCompat.requestPermissions(this,PERMISSIONS,REQUEST_PERMISSIONS);
        }
    }
    private boolean isGranted(){
        for(int i =0; i<PERMISSION.length; i++){
            if(PermissionChecker.checkSelfPermission(
                    AppDelegate.this, PERMISSIONS[i]) !=
                    PackageManager.PERMISSION_GRANTED) {
                    return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requsetCode, String permissions[], int[] results){
        if(requestCode == REQUEST_PERMISSIONS){
            permissionGranted = true;
        }else{
            super.onRequestPermissionsResult(requestCode, permissions, results);
        }
    }




    public static Bitmap modifyOrientation(Bitmap bitmap, InputStream in){
        try{
            ExifInterface ei = new ExifInterface(in);
            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
            if(orientation == ExifInterface.ORIENTATION_ROTATE_90){
                return rotate(bitmap,90);
            }else if(orientation == ExifInterface.ORIENTATION_ROTATE_180){
                return rotate(bitmap,180);
            }else if(orientation == ExifInterface.ORIENTATION_ROTATE_270){
                return rotate(bitmap,270);
            }else if(orientation == ExifInterface.ORIENTATION_FLIP_HORIZONTAL){
                return flip(bitmap,true,false);
            }else if(orientation == ExifInterface.ORIENTATION_FLIP_VERTICAL){
                return flip(bitmap,false,true);
            }
        }catch(IOException e){
            e.printStackTrace();
        }
        return bitmap;
    }

    public static Bitmap rotate(Bitmap bitmap, float degrees){
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bitmap, 0, 0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    }

    public static Bitmap flip(Bitmap bitmap, boolean horizontal, boolean vertical){
        Matrix matrix = new Matrix();
        matrix.preScale(horizontal ? -1 : 1, vertical ? -1 : 1);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    }

//    FirebaseVisionLabelDetectorOptions options =
//            new FirebaseVisionLabelDetectorOptions.Builder()
//            .setConfidenceThreshold(0.75f)
//            .build();
//    FirebaseVisionLabelDetector labelDetector = FirebaseVision.getInstance()
//            .getVisionLabelDetector(options);
//
//    labelDetector.detectInImage(visionImage)
//            .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionLabel>>(){
//
//                @Override
//                public void onSuccess(List<FirebaseVisionLabel> labels){
//                    String text = "\n";
//                    for(FirebaseVisionLabel label: labels){
//                        text += label.getLabel()+" : " + (int)(label.getConfidence()*100)+"%\n";
//                    }
//                    final String str = text;
//
//                    post(new Runnable(){
//                        @Override
//                        public void run() {
//                            lblText.setText(str);
//                            lblText.setVisibility(
//                                    str.length() == 0 ? View.GONE : View.VISIBLE);
//                        }
//                    });
//                }
//            })
//            .addOnFailureListener(new OnFailureListener(){
//                @Override
//                public void OnFailure(@NonNull Exception e){
//                    showAlert(e.getMessage());
//                }
//                });
//            }
    FirebaseVisionCloudDetectorOptions options = new FirebaseVisionCloudDetectorOptions.Builder()
        .setModelType(FirebaseVisionCloudDetectorOptions.LATEST_MODEL)
        .setMaxResults(20)
        .build();
    FirebaseVisionCloudLabelDetector labelDetector = FirebaseVision.getInstance()
            .getVisionCloudLabelDetector(options);

    labelDetector.detectInImage(visionImage)
            .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionCloudLabel>>()
    {
        @Override
        public void onSuccess(List<FirebaseVisionCloudLabel> labels){
            String text = "\n";
            for(FirebaseVisionLabel label: labels){
                text += label.getLabel()+" : " +
                        (int)(label.getConfidence()*100)+"%\n";
            }
            final String str = text;

            post(new Runnable(){
                @Override
                public void run() {
                        lblText.setText(str);
                        lblText.setVisibility(
                                str.length() == 0 ? View.GONE : View.VISIBLE);
                    }
                });
            }
        })
            .addOnFailureListener(new OnFailureListener(){
            @Override
            public void OnFailure(@NonNull Exception e){
                showAlert(e.getMessage());
            }
        });
    }
}


