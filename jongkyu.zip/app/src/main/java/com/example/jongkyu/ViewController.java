package com.example.jongkyu;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.view.View;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.label.FirebaseVisionLabel;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetector;
import com.google.firebase.ml.vision.label.FirebaseVisionLabelDetectorOptions;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class ViewController {
    FirebaseVisionImage visionImage = FirebaseVisionImage.fromBitmap(image);
    public static Bitmap modifyOrientation(Bitmap bitmap, InputStream in){
        try{
            ExifInterface ei = new ExifInterface(in);
            int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
            if(orientation == ExifInterface.ORIENTATION_ROTATE_90){
                return rotate(bitmap,90);
            }else if(orientation == ExifInterface.ORIENTATION_ROTATE_180){
                return rotate(bitmap,180);
            }else if(orientation == ExifInterface.ORIENTATION_ROTATE_270){
                return rotate(bitmap,270);
            }else if(orientation == ExifInterface.ORIENTATION_FLIP_HORIZONTAL){
                return flip(bitmap,true,false);
            }else if(orientation == ExifInterface.ORIENTATION_FLIP_VERTICAL){
                return flip(bitmap,false,true);
            }
        }catch(IOException e){
            e.printStackTrace();
        }
        return bitmap;
    }

    public static Bitmap rotate(Bitmap bitmap, float degrees){
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(bitmap, 0, 0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    }

    public static Bitmap flip(Bitmap bitmap, boolean horizontal, boolean vertical){
        Matrix matrix = new Matrix();
        matrix.preScale(horizontal ? -1 : 1, vertical ? -1 : 1);
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(),bitmap.getHeight(),matrix,true);
    }

    FirebaseVisionLabelDetectorOptions options = new FirebaseVisionLabelDetectorOptions.Builder()
            .setConfidenceThreshold(0.75f)
            .build();
    FirebaseVisionLabelDetector labelDetector = FirebaseVision.getInstance()
            .getVisionLabelDetector(options);

    labelDetector.detectInImage(visionImage)
            .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionLabel>>(){

                @Override
                public void onSuccess(List<FirebaseVisionLabel> labels){
                    String text = "\n";
                    for(FirebaseVisionLabel label: labels){
                        text += label.getLabel()+" : " + (int)(label.getConfidence()*100)+"%\n";
                    }
                    final String str = text;

                    post(new Runnable(){
                        @Override
                        public void run() {
                            lblText.setText(str);
                            lblText.setVisibility(
                                    str.length() == 0 ? View.GONE : View.VISIBLE);
                        }
                    });
                }
            })
            .ADDoNfAILURElISTENER(new OnFailureListener(){
                @Override
                public void OnFailure(@NonNull Exception e){
                    showAlert(e.getMessage());
        }
    });
}


